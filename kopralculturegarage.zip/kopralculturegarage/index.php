<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kopral Culture Garage</title>

  <!-- Bootstrap CSS Offline -->
  <link href="bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Chart.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    html {
      scroll-behavior: smooth; /* Smooth Scroll */
    }
    .nav-link.active {
      color: #ffc107 !important;
      font-weight: bold;
      border-bottom: 2px solid #ffc107;
    }
  </style>
</head>
<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-offset="70" style="background-color:#000; color:#fff;">



  <!-- NAVBAR -->
  <nav id="navbar" class="navbar navbar-expand-lg navbar-dark fixed-top shadow-sm" style="background-color:#111;">
    <div class="container">
      <a class="navbar-brand fw-bold text-warning" href="#home">kopralculturegarage.</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navmenu">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#portfolio">What We Do</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- HERO / HOME dengan Carousel -->
  <section id="home" class="vh-100">
    <div id="heroCarousel" class="carousel slide carousel-fade vh-100" data-bs-ride="carousel" data-bs-interval="3000">
      <div class="carousel-inner vh-100">

        <!-- Slide 1 -->
        <div class="carousel-item active vh-100" style="background: url('kopralcustomculture.png') center/cover no-repeat;">
          <div class="d-flex h-100 align-items-center justify-content-center text-white" style="background: rgba(0,0,0,0.5);">
            <div class="text-center"></div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item vh-100" style="background: url('grand.png') center/cover no-repeat;">
          <div class="d-flex h-100 align-items-center justify-content-center text-white" style="background: rgba(0,0,0,0.5);">
            <div class="text-center"></div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item vh-100" style="background: url('gl&w175.png') center/cover no-repeat;">
          <div class="d-flex h-100 align-items-center justify-content-center text-white" style="background: rgba(0,0,0,0.5);">
            <div class="text-center"></div>
          </div>
        </div>

      </div>

      <!-- Tombol navigasi -->
      <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>
  </section>

  <!-- PORTFOLIO SECTION -->
   <!--
 <section id="portfolio" class="py-5" style="background-color:#111;">
    <div class="container">
      <h2 class="text-center mb-5 text-warning fw-bold">What We Do</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card shadow-sm bg-dark text-light border-0">
            <img src="bodyworks.png" class="card-img-top" alt="Bodyworks">
            <div class="card-body">
              <h5 class="card-title text-warning">Bodyworks</h5>
              <p class="card-text">High-aesthetic motorcycle bodywork.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow-sm bg-dark text-light border-0">
            <img src="choppskuy.png" class="card-img-top" alt="Customworks">
            <div class="card-body">
              <h5 class="card-title text-warning">Customworks</h5>
              <p class="card-text">Customizing motorcycles to match with your style.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow-sm bg-dark text-light border-0">
            <img src="paintworks.png" class="card-img-top" alt="Paintworks">
            <div class="card-body">
              <h5 class="card-title text-warning">Paintworks</h5>
              <p class="card-text">Personalized striping and airbrush based on your request.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> 
  --> 

  <section id="portfolio" class="py-5" style="background-color:#111;">
  <div class="container">
    <div class="text-center mb-5 text-warning fw-bold">
      <h2>What We Do</h2>
    </div>
    <div id="services-container" class="row g-4">
      <!-- Konten dari database akan dimasukkan lewat JS -->
    </div>
  </div>
</section>

<script>
fetch('services.php')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('services-container');
    container.innerHTML = '';

    data.forEach(service => {
      const col = document.createElement('div');
      col.className = "col-md-4";

      col.innerHTML = `
        <div class="card shadow-sm bg-dark text-light border-0">
          <img src="${service.image}" class="card-img-top" alt="${service.title}">
          <div class="card-body">
            <h5 class="card-title text-warning">${service.title}</h5>
            <p class="card-text">${service.description}</p>
          </div>
        </div>
      `;
      container.appendChild(col);
    });
  })
  .catch(err => console.error('Gagal ambil data:', err));
</script>

  <!-- ABOUT SECTION -->

  <section id="about" class="py-5" style="background-color:#000;">
  <div class="container">
    <h2 class="text-center mb-5 text-warning fw-bold">About Us</h2>
    <div class="row align-items-center">
      <div class="col-md-6">
        <img src="kopralcustomculture.png" class="img-fluid rounded-3 shadow" alt="Workshop">
      </div>
      <div class="col-md-6">
        <h3 class="text-warning">kopralculturegarage.</h3>
        <p>We specialize in crafting one-of-a-kind motorcycles that combine precision engineering with artistic design.</p>
        <p>With years of hands-on experience, we offer a full range of services including bodyworks, custom builds, and premium paintworks. Every project is approached with meticulous attention to detail, ensuring both performance and aesthetics are at the highest standard.</p>
 
          
          <!-- CANVAS CHART -->
           
          <canvas id="aboutChart" height="200"></canvas>
        </div>
      </div>
    </div>
  </section>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
fetch('projects.php')
  .then(response => response.json())
  .then(data => {
    const counts = {};

    // Hitung jumlah project per service
    data.forEach(project => {
      if (!counts[project.title]) counts[project.title] = 0;
      counts[project.title]++;
    });

    const labels = Object.keys(counts);
    const values = Object.values(counts);

    const ctx = document.getElementById('aboutChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Projects Completed (Dynamic)',
          data: values,
          backgroundColor: ['#ffc107', '#ff9800', '#ff5722']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          title: {
            display: true,
            text: 'Our Completed Projects (Dynamic Data)',
            color: '#fff'
          }
        },
        scales: {
          x: { ticks: { color: '#fff' } },
          y: { ticks: { color: '#fff', precision: 0 } }
        }
      }
    });
  })
  .catch(err => console.error('Gagal ambil data projects:', err));
</script>

<!-- Contact Form Section -->
<!-- Contact Form Section -->
<section class="contact-form" style="background-color:#1a1a1a; padding:30px; text-align:center;">
  <h2 style="color:#ffcc00;">Contact Us</h2>

  <form id="contactForm" style="max-width:600px; margin:0 auto; display:flex; flex-direction:column; gap:15px;">
    <input type="text" name="name" placeholder="Your Name" required 
           style="padding:10px; border-radius:8px; border:none;">
    <input type="email" name="email" placeholder="Your Email" required
           style="padding:10px; border-radius:8px; border:none;">
    <textarea name="message" placeholder="Your Message" required rows="5"
              style="padding:10px; border-radius:8px; border:none;"></textarea>
    <button type="submit" 
            style="background:#ffcc00; color:#000; font-weight:bold; padding:10px; border:none; border-radius:8px; cursor:pointer;">
      Send Message
    </button>
  </form>

  <!-- Pesan sukses/gagal -->
  <p id="responseMessage" style="color:#00ff00; font-weight:bold; display:none; margin-top:15px;"></p>
</section>

<!-- Script AJAX -->
<script>
document.getElementById('contactForm').addEventListener('submit', async function(e) {
  e.preventDefault(); // cegah reload

  let formData = new FormData(this);

  try {
    let response = await fetch('save_contact.php', {
      method: 'POST',
      body: formData
    });

    let result = await response.text();

    document.getElementById('responseMessage').innerText = "✅ Terima kasih! Pesan kamu sudah terkirim.";
    document.getElementById('responseMessage').style.display = "block";

    this.reset(); // reset form setelah kirim

  } catch (error) {
    document.getElementById('responseMessage').innerText = "❌ Gagal mengirim pesan.";
    document.getElementById('responseMessage').style.color = "#ff0000";
    document.getElementById('responseMessage').style.display = "block";
  }
});
</script>



  <!-- CONTACT SECTION -->
  <section id="contact" class="py-5" style="background-color:#111;">
    <div class="container">
      <h2 class="text-center mb-5 text-warning fw-bold">Stay in Touch with us</h2>
      <div class="row justify-content-center">
        <div class="col-md-6 text-center">
          <p class="text-light mb-4">Our Social Media </p>
          <a href="https://wa.me/6281325696489" target="_blank" class="btn btn-success btn-lg mb-3 d-block fw-bold">
            WhatsApp Us
          </a>
          <a href="https://www.instagram.com/mikael.chrst_" target="_blank" class="btn btn-danger btn-lg d-block fw-bold">
            Follow on Instagram
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="text-white text-center py-3" style="background-color:#000;">
    <p class="mb-0">&copy; kopralculturegarage.</p>
  </footer>

  <!-- Bootstrap JS Offline -->
  <script src="bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>

  <!-- Custom JavaScript -->
  <script>
    // === ACTIVE MENU HANDLER ===
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', function() {
        navLinks.forEach(l => l.classList.remove('active'));
        this.classList.add('active');
      });
    });

    // === CHART.JS (ABOUT SECTION) ===
   
  </script>
</body>
</html>

