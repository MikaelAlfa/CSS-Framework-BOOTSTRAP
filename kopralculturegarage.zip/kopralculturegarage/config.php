<?php
// config.php
$host = "localhost";
$user = "user20232022";       // default user XAMPP
$pass = "Xs5lqg";           // default password XAMPP kosong
$db   = "user20232022";

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?> 