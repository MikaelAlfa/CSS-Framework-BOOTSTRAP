<?php
// config.php
$host = "localhost";
$user = "root";       // default user XAMPP
$pass = "";           // default password XAMPP kosong
$db   = "kopralculturegarage";

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?> 