<?php
include 'config.php';

// Ambil data projects
$sql = "SELECT projects.id, projects.project_name, services.title 
        FROM projects 
        INNER JOIN services ON projects.service_id = services.id";
$result = $conn->query($sql);

$projects = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
}

echo json_encode($projects);
?>  